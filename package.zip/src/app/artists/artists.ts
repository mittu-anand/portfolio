export class Artists {
	id:number;
	name:string;
	picture:string;
	age:number;
	desc:string;
	tag:string;
	websites:string;
}